//
//  ICLine.h
//  Panels
//
//  Created by Tomáš Hanáček on 5/24/16.
//  Copyright © 2016 Tomas Hanacek. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ICLine : NSView

@end
