//
//  VDKSketchMSLayerInspectorViewControllerProtocol.h
//  KeysForSketch
//
//  Created by Vyacheslav Dubovitsky on 17/09/2017.
//  Copyright © 2017 Vyacheslav Dubovitsky. All rights reserved.
//

@protocol VDKSketchMSLayerInspectorViewControllerProtocol <NSObject>

@property(nullable, nonatomic) __weak NSButton *lockProportionsButton;

@end
