//
//  KeysForSketch.h
//  KeysForSketch
//
//  Created by Vyacheslav Dubovitsky on 15/07/2017.
//  Copyright © 2017 Vyacheslav Dubovitsky. All rights reserved.
//

#import <MASShortcut/Shortcut.h>
#import "VDKSketchAPI.h"
#import "VDK_JRSwizzle.h"
#import "NSMenuItem+Private.h"
#import "lorgnette.h"
#import "lorgnette-structs.h"
