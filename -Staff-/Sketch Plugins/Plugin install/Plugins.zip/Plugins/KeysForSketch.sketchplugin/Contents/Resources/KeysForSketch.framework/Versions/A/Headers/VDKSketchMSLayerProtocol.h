//
//  VDKSketchMSLayerProtocol.h
//  KeysForSketch
//
//  Created by Vyacheslav Dubovitsky on 04/09/2017.
//  Copyright © 2017 Vyacheslav Dubovitsky. All rights reserved.
//

@protocol VDKSketchMSLayerProtocol

@property(nonnull, retain, nonatomic) NSString *nodeName;

@end
