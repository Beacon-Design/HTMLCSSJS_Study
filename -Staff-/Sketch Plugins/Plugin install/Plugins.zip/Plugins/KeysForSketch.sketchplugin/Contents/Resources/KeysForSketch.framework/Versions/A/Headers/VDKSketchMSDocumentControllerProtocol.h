//
//  VDKSketchMSDocumentControllerProtocol.h
//  KeysForSketch
//
//  Created by Vyacheslav Dubovitsky on 27/03/2017.
//  Copyright © 2017 Vyacheslav Dubovitsky. All rights reserved.
//

@protocol VDKSketchMSDocumentProtocol;

@protocol VDKSketchMSDocumentControllerProtocol

+ (nonnull instancetype)sharedDocumentController;

@end
