//
//  VDKSketchMSArtboardGroupProtocol.h
//  KeysForSketch
//
//  Created by Vyacheslav Dubovitsky on 04/09/2017.
//  Copyright © 2017 Vyacheslav Dubovitsky. All rights reserved.
//

@protocol VDKSketchMSLayerGroupProtocol;

@protocol VDKSketchMSArtboardGroupProtocol <VDKSketchMSLayerGroupProtocol>

@end
